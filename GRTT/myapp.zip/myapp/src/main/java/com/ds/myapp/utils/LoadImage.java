package com.ds.myapp.utils;

/**
 * 下载图片 工具类
 * Created by xxxxx on 2016/10/20.
 */
public class LoadImage {
}
