package com.ds.master;

import android.test.AndroidTestCase;

/**
 * Created by Administrator on 2016/10/13.
 */
public class XXXXXTest extends AndroidTestCase{
    public void test_xxxxx(){
        String s = "";
        s.isEmpty();
        s.indexOf("dfghjk");
    }
}
