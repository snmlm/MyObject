package com.ds.myapp.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * acitivity基础类
 * Created by xxxxx on 2016/10/20.
 */
public class BaseActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        init();
        initData();
        setListener();
    }

    public void init(){}
    public void initData(){}
    public void setListener(){}

}
