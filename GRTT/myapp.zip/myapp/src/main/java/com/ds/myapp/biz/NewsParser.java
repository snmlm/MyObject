package com.ds.myapp.biz;

/**
 * 新闻分析
 * Created by xxxxx on 2016/10/20.
 */
public class NewsParser {
}
