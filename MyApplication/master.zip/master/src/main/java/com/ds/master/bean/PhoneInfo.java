package com.ds.master.bean;

/**
 * Created by Administrator on 2016/0/25.
 */

public class PhoneInfo {

    public String idx;
    public String name;
    public String namec;
    public String number;

    public PhoneInfo(String idx, String name,String namec,String number){

        this.idx = idx;
        this.name = name;
        this.namec = namec;
        this.number = number;
    }

}
