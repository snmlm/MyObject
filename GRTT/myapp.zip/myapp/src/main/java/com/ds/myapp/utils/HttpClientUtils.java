package com.ds.myapp.utils;

/**
 * http连接 工具类
 * Created by xxxxx on 2016/10/20.
 */
public class HttpClientUtils {
}
