package com.ds.myapp.entiy;

/**
 * 新闻实体
 * Created by xxxxx on 2016/10/20.
 */
public class News {
}
