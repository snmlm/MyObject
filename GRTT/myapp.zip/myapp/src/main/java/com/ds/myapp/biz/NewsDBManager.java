package com.ds.myapp.biz;

/**
 * 新闻db管理类
 * Created by xxxxx on 2016/10/20.
 */
public class NewsDBManager {
}
