package com.ds.master;

import android.hardware.Camera;
import android.test.AndroidTestCase;
import android.util.Log;

import java.util.List;

/**
 * Created by Administrator on 2016/10/13.
 */
public class XXXXXText extends AndroidTestCase{
    public void text_xxxxx(){

        Camera camera = Camera.open();
        List<Camera.Size> supportedPreviewSizes = camera.getParameters().getSupportedPreviewSizes();

        for (Camera.Size size : supportedPreviewSizes){
            Log.e("xxxxx",size.width + "  "+ size.height);
        }
    }
}
