package com.ds.master;

import android.test.InstrumentationTestCase;

import com.ds.master.utils.Demo;

/**
 * Created by Administrator on 2016/10/14.
 */
public class DemoTest extends InstrumentationTestCase {

    public void test_xxxxx(){
        new Demo().run();
    }
}
