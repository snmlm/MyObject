package com.ds.myapp.activity;

import com.ds.myapp.R;

/**
 * 主页面 显示
 * Created by xxxxx on 2016/10/20.
 */
public class HomeActivity extends BaseActivity {
    @Override
    public void init() {
        setContentView(R.layout.activity_home);
    }
}
